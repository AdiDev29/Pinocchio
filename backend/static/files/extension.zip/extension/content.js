// This content script is injected into web pages
// We don't need any functionality here right now as we're extracting content via the popup script
console.log("Pinocchio extension loaded");